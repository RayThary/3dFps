using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum EnemyType
{
    EnemyA,
    EnemyB,
    EnemyC,
    EnemyF,
    EnemyBoss,
}

[CreateAssetMenu(menuName = "Game/EnemyData", fileName = "NewEnemyData")]
public class EnemyData : ScriptableObject
{

    public EnemyType enemyType;
    [Tooltip("enum �̸��� ǥ���մϴ�")]
    public string EnemyName;

    public float Hp;
    public float Damage;
    public float Speed;
    public float AttackStopRange;//���� �������ߴ°Ÿ�
    public float chaseDistance;//�߰ݹ���
    private void OnValidate()
    {
        EnemyName = enemyType.ToString();
    }

}



