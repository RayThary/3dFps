using System.Collections;
using System.Collections.Generic;
using System.Threading;
using UnityEngine;
//using static UnityEditor.Searcher.SearcherWindow.Alignment;

public class UnitMovement
{
    //�̵�
    private Vector3 moveVec;
    public Vector3 GetMoveVec { get { return moveVec; } }

    //����
    private bool isGround;

    //�⺻
    private Transform unitTransform;
    private Animator anim;
    private Rigidbody rigid;

    private PlayerInput input;

    public void SetUp(Transform _transform, Animator _anim, Rigidbody _rigid, PlayerInput _input)
    {
        unitTransform = _transform;
        anim = _anim;
        rigid = _rigid;
        input = _input;
    }

    public void UnitMove(float _speed,bool _isDodge,Vector3 _dodgeVec)
    {
        moveVec = (unitTransform.right * input.GetAxis[InputAction.Horizontal]) + 
            (unitTransform.forward * input.GetAxis[InputAction.Vertical]);

        if (_isDodge) moveVec = _dodgeVec;

        unitTransform.position += moveVec * _speed * Time.deltaTime;

        anim.SetBool("Run", moveVec != Vector3.zero);
    }

    public void jump(float _jumpPower,PlayerInput _playerInput)
    {
        isGround = Physics.Raycast(unitTransform.position, Vector3.down, 0.5f, LayerMask.GetMask("Ground"));
        if (_playerInput.ButtonDown[InputAction.Jump] && isGround)
        {
            anim.SetBool("isJump", true);
            anim.SetTrigger("Jump");
            rigid.AddForce(Vector3.up * _jumpPower, ForceMode.Impulse);
            _playerInput.ButtonDown[InputAction.Jump] = false;
        }
    }

    public bool dodge()
    {
        if (input.ButtonDown[InputAction.LeftShift])
        {
            return true;
        }
        return false;
    }


  
}
