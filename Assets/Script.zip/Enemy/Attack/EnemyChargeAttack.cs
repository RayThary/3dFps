using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyChargeAttack : MonoBehaviour
{
    private Enemy enemy;
    private BoxCollider box;

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.layer == LayerMask.NameToLayer("Player"))
        {
            if (enemy.IsDead) return;
            other.GetComponent<Unit>().TakeDamge(enemy.Damage);   
        }
    }

    void Start()
    {
        enemy = GetComponentInParent<Enemy>();
        box = GetComponent<BoxCollider>();
        box.enabled = false;
    }

    private void attackEnd()
    {
        enemy.EnemyChargeAttackEnd();
    }

    //�ִϸ��̼� �̺�Ʈ�߰��� 
    private void DeathEnd()
    {
        enemy.EnemyDeath();
    }
}
