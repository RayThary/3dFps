using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IEnemyState
{
    void Enter();
    void Update();
    void Exit();

    bool CanEnter { get; set; }
}
