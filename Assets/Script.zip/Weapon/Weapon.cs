using Cinemachine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class Weapon
{
    public string GetName { get { return weaponName; } }
    protected PoolingManager.ePoolingObject poolingMuzzle;
    protected Bullet.BulletType bulletType;

    protected string weaponName;
    protected int maxAmmo;
    protected int currentAmmo;
    protected int reserveAmmo;
    protected int maxReserveAmmo;
    protected float speed;

    protected int weaponMaxLevel;
    public int WeaponMaxLevel { get { return weaponMaxLevel; } }
    protected float weaponLevelUpDamage;
    public float WeaponLevelUpDamage { get { return weaponLevelUpDamage; } }
    protected bool isMelee;
    public bool IsMelee { get { return isMelee; } }

    protected float recoilPower;
    public float GetRecoilPower { get { return recoilPower; } }

    protected float damage;
    public float GetDamage { get { return damage; } }

    protected bool isReloading;
    public bool IsReloading { set { isReloading = value; } }
    protected float recoilRecoverSpeed;
    public float GetRecoilRecoverSpeed { get { return recoilRecoverSpeed; } }

    protected eWeaponType weaponType;
    public eWeaponType WeaponType { get { return weaponType; } }

    //UI �Ѿ�
    public int GetCurrentAmmo { get { return currentAmmo; } }
    public int GetReserveAmmo { get { return reserveAmmo; } }

    protected bool automatic;
    public bool Automatic { get { return automatic; } protected set { automatic = value; } }
    protected bool zoomWeapon;
    public bool ZoomWeapon { get { return zoomWeapon; } }

    protected GameObject weaponPrefeb;
    public GameObject WeaponPrefeb { get { return weaponPrefeb; } protected set { weaponPrefeb = value; } }

    private Animator animator;
    public Animator Animator { get { return animator; } set { animator = value; } }

    //��, ���� ����
    public Weapon(WeaponData _data)
    {
        weaponType = _data.WeaponType;
        weaponName = _data.WeaponName;
        damage = _data.Damage;
        weaponPrefeb = _data.Prefab;
        isMelee = _data.isMelee;
        weaponMaxLevel = _data.weaponMaxLevel;
        weaponLevelUpDamage = _data.weaponLevelUpDamage;
        recoilRecoverSpeed = _data.RecoilRecoverSpeed;

                currentAmmo = _data.MaxAmmo;
        maxAmmo = _data.MaxAmmo;

        reserveAmmo = _data.PullAmmo / 2;
        maxReserveAmmo = _data.PullAmmo;

        automatic = _data.Automatic;
        bulletType = _data.BulletType;
        poolingMuzzle = _data.PoolingMuzzle;
        recoilPower = _data.RecoilPower;
        zoomWeapon = _data.ZoomWeapon;
    }
    public Weapon(WeaponData _data, bool _melee)
    {
        weaponType = _data.WeaponType;
        weaponName = _data.WeaponName;
        damage = _data.Damage;
        weaponPrefeb = _data.Prefab;
        isMelee = _data.isMelee;
        reserveAmmo = _data.PullAmmo / 2;
        maxReserveAmmo = _data.PullAmmo;
        currentAmmo = _data.MaxAmmo;
        maxAmmo = _data.MaxAmmo;
    }

    public abstract bool Attack(Transform _muzzlePoint);
    public virtual void Reload(WeaponView _weaponView)
    {
        if (currentAmmo == maxAmmo || reserveAmmo <= 0 || isReloading)
        {
            Debug.Log("������ �Ǵ� �Ѿ��� �����ְų� ������");
            return;
        }
        isReloading = true;
        _weaponView.UnitReloadAnim();
        Debug.Log("���� ");
    }

    public virtual void Reload(Animator _anim)
    {
        if (currentAmmo == maxAmmo || reserveAmmo <= 0 || isReloading)
        {
            Debug.Log("������ �Ǵ� �Ѿ��� �����ְų� ������");
            return;
        }
        isReloading = true;
        _anim.SetTrigger("Reload");
    }

    public void ReloadAmmo()
    {
        int needAmmo = maxAmmo - currentAmmo;
        int ammoLoad = Mathf.Min(needAmmo, reserveAmmo);
        currentAmmo += ammoLoad;
        reserveAmmo -= ammoLoad;
    }

    public void GetGunDamage(int _weaponLevel)
    {
        damage = damage + (_weaponLevel * 5);
    }

    public abstract void Zoomable(CinemachineVirtualCamera _vCamera, bool _zoom);

    
}




